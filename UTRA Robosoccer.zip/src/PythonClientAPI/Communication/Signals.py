from enum import Enum

Signals = Enum('Signals',
               'MOVE BEGIN END NO_RESPONSE GET_READY READY')
